#!/usr/bin/env python3
"""One crash-reconciling Post relay tick, implementing SPEC-v2 r5.2."""

import argparse
import datetime as dt
import errno
import fcntl
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from dataclasses import replace as dataclass_replace
from pathlib import Path, PurePosixPath

# The installed launcher may execute this file from any cwd.  Put the package
# directory on sys.path before importing bridgelib.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bridgelib import channels, rooms, tick  # noqa: E402
from bridgelib.common import (  # noqa: E402
    blocked_reason,
    load_rules,
    DEFAULT_DEADLINE_SECONDS,
    DEFAULT_FETCH_GRACE_SECONDS,
    DEFAULT_MAX_MAIL_BYTES,
    ENVELOPE_OPTIONAL,
    ENVELOPE_REQUIRED,
    GIT_NETWORK_TIMEOUT_SECONDS,
    GIT_TIMEOUT_SECONDS,
    LOG_ROTATE_BYTES,
    MAIL_ADDRESS_KINDS,
    MAIL_KINDS,
    MAX_MAX_MAIL_BYTES,
    RECEIPT_KEYS,
    RECEIPT_STATUSES,
    RELAY_WARN_BYTES,
    REMOTE_PARTICIPANT_UNHOMED,
    SENDER_NOT_HOMED,
    SHA256_RE,
    ConfigError,
    DeadlineExpired,
    GitReadError,
    HoldLedger,
    TickError,
    atomic_replace,
    checkpoint,
    destination,
    ensure_dir,
    epoch_from_iso,
    exclusive_publish,
    fold_name,
    fsync_directory,
    load_json_bytes,
    note_git_failure,
    open_regular,
    post_environment,
    post_sees_remote,
    parse_positive_int,
    realpath_equal,
    under,
    utc_now,
    validate_host,
    validate_id,
    validate_attribution,
    validate_path_component,
    validate_room,
)
from bridgelib.snapshot import (  # noqa: E402
    FORGED_SELF,
    NAME_COLLISION,
    UNHOMED,
    UNPUBLISHED_SENDER,
    VERIFIED,
    binding_verdict,
)

PINNED_POST_VERSION = "post 0.9.0"


class Deadline:
    def __init__(self, seconds):
        self.ends = time.monotonic() + seconds

    def remaining(self):
        return self.ends - time.monotonic()

    def check(self):
        if self.remaining() <= 0:
            raise DeadlineExpired()

    def timeout(self, ceiling):
        self.check()
        return max(1, min(ceiling, int(self.remaining()) + 1))


class Logger:
    def __init__(self, root):
        self.root = root
        self.bridge = destination(root, "bridge")
        ensure_dir(root, self.bridge)
        self.path = destination(root, "bridge", "log.jsonl")

    def emit(self, action, **fields):
        record = {"ts": utc_now(), "action": action}
        record.update(fields)
        line = json.dumps(record, sort_keys=True, separators=(",", ":"))
        print(line, flush=True)
        try:
            if self.path.exists() and self.path.stat().st_size >= LOG_ROTATE_BYTES:
                rotated = self.path.with_name("log.jsonl.1")
                if rotated.exists() or rotated.is_symlink():
                    rotated.unlink()
                os.replace(str(self.path), str(rotated))
            flags = (
                os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
            )
            descriptor = os.open(str(self.path), flags, 0o600)
            try:
                os.write(descriptor, (line + "\n").encode("utf-8"))
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        except OSError as error:
            print(f"post-bridge: cannot persist log: {error}", file=sys.stderr)


@dataclass
class Settings:
    root: Path
    repo: Path
    host: str
    ssh_key: Path
    post_bin: str
    max_mail_bytes: int
    deadline_seconds: int
    fetch_grace_seconds: int


@dataclass
class Config:
    host: str
    relay_url: str
    peers: dict
    channels: object = None


class Git:
    def __init__(self, settings, deadline):
        self.settings = settings
        self.deadline = deadline
        # m6: per-host read failures this tick (host, ref, path).
        self.read_failures = []
        self.environment = os.environ.copy()
        self.environment["GIT_SSH_COMMAND"] = (
            f"ssh -o ConnectTimeout=10 -o BatchMode=yes -i {shlex_quote(str(settings.ssh_key))} "
            "-o IdentitiesOnly=yes"
        )

    def run(self, args, check=True, network=False, text=True):
        timeout = self.deadline.timeout(
            GIT_NETWORK_TIMEOUT_SECONDS if network else GIT_TIMEOUT_SECONDS
        )
        result = subprocess.run(
            ["git", "-C", str(self.settings.repo)] + list(args),
            env=self.environment,
            capture_output=True,
            text=text,
            timeout=timeout,
            check=False,
        )
        if check and result.returncode != 0:
            stdout = result.stdout if text else result.stdout.decode("utf-8", "replace")
            stderr = result.stderr if text else result.stderr.decode("utf-8", "replace")
            raise TickError(
                "git_failed",
                "git {} failed: {}{}".format(" ".join(args), stdout, stderr),
            )
        return result

    def rev(self, ref):
        result = self.run(["rev-parse", "--verify", ref], check=False)
        return result.stdout.strip() if result.returncode == 0 else None

    def is_ancestor(self, older, newer):
        return (
            self.run(
                ["merge-base", "--is-ancestor", older, newer], check=False
            ).returncode
            == 0
        )

    def ls_tree(self, ref, prefix):
        result = self.run(
            ["ls-tree", "-r", "-l", "-z", ref, "--", prefix],
            check=False,
            text=False,
        )
        if result.returncode != 0:
            # m6: a nonzero ls-tree is a real failure (a missing path exits
            # 0 with no output); an empty list would silently skip the peer.
            raise GitReadError(
                ref, prefix, result.stderr.decode("utf-8", "replace").strip()
            )
        entries = []
        for record in result.stdout.split(b"\0"):
            if not record:
                continue
            metadata, separator, raw_path = record.partition(b"\t")
            if not separator:
                continue
            fields = metadata.split()
            if len(fields) != 4:
                continue
            try:
                size = None if fields[3] == b"-" else int(fields[3])
            except ValueError:
                continue
            try:
                path = raw_path.decode("utf-8")
            except UnicodeDecodeError:
                path = None
            entries.append(
                {
                    "mode": fields[0].decode("ascii", "replace"),
                    "type": fields[1].decode("ascii", "replace"),
                    "object": fields[2].decode("ascii", "replace"),
                    "size": size,
                    "path": path,
                    "raw_path": raw_path,
                }
            )
        return entries

    def show(self, ref, path):
        result = self.run(["show", f"{ref}:{path}"], check=False, text=False)
        return result.stdout if result.returncode == 0 else None


def shlex_quote(value):
    return "'{}'".format(value.replace("'", "'\"'\"'"))


def load_settings():
    required = ("POST_MAIL_ROOT", "BRIDGE_REPO", "BRIDGE_HOST", "BRIDGE_SSH_KEY")
    missing = [name for name in required if not os.environ.get(name)]
    if missing:
        raise ConfigError("missing required environment: {}".format(", ".join(missing)))
    root = Path(os.environ["POST_MAIL_ROOT"])
    repo = Path(os.environ["BRIDGE_REPO"])
    ssh_key = Path(os.environ["BRIDGE_SSH_KEY"])
    for name, path in (
        ("POST_MAIL_ROOT", root),
        ("BRIDGE_REPO", repo),
        ("BRIDGE_SSH_KEY", ssh_key),
    ):
        if not path.is_absolute() or not realpath_equal(path):
            raise ConfigError(f"{name} must be absolute and canonical")
    if not root.is_dir():
        raise ConfigError("POST_MAIL_ROOT must be an existing directory")
    if not repo.is_dir() or not (repo / ".git").exists():
        raise ConfigError("BRIDGE_REPO must be an existing Git worktree")
    try:
        key_metadata = ssh_key.lstat()
    except FileNotFoundError:
        raise ConfigError("BRIDGE_SSH_KEY does not exist")
    if not stat.S_ISREG(key_metadata.st_mode) or ssh_key.is_symlink():
        raise ConfigError("BRIDGE_SSH_KEY must be a regular file")
    if stat.S_IMODE(key_metadata.st_mode) != 0o600:
        raise ConfigError("BRIDGE_SSH_KEY must have mode 0600")
    host = os.environ["BRIDGE_HOST"]
    validate_host(host, "BRIDGE_HOST")
    max_bytes = parse_positive_int(
        os.environ.get("BRIDGE_MAX_MAIL_BYTES"),
        "BRIDGE_MAX_MAIL_BYTES",
        DEFAULT_MAX_MAIL_BYTES,
        MAX_MAX_MAIL_BYTES,
    )
    deadline_raw = os.environ.get("BRIDGE_TICK_DEADLINE_SECONDS")
    deadline_seconds = parse_positive_int(
        deadline_raw,
        "BRIDGE_TICK_DEADLINE_SECONDS",
        DEFAULT_DEADLINE_SECONDS,
    )
    fetch_grace = parse_positive_int(
        os.environ.get("BRIDGE_FETCH_GRACE_SECONDS"),
        "BRIDGE_FETCH_GRACE_SECONDS",
        DEFAULT_FETCH_GRACE_SECONDS,
    )
    return Settings(
        root=root,
        repo=repo,
        host=host,
        ssh_key=ssh_key,
        post_bin=os.environ.get("POST_BIN", "post"),
        max_mail_bytes=max_bytes,
        deadline_seconds=deadline_seconds,
        fetch_grace_seconds=fetch_grace,
    )


def load_config(settings):
    path = destination(settings.root, "bridge", "config.json")
    try:
        data = open_regular(path, 1024 * 1024)
    except (FileNotFoundError, ConfigError) as error:
        raise ConfigError(f"cannot read config.json: {error}")
    value = load_json_bytes(data, str(path))
    allowed_keys = {"host", "relay_url", "peers", "channels"}
    required_keys = {"host", "relay_url"}
    if (
        not isinstance(value, dict)
        or not required_keys.issubset(value)
        or not set(value).issubset(allowed_keys)
    ):
        raise ConfigError(
            "config.json must contain host and relay_url, with optional peers and channels"
        )
    validate_host(value["host"], "config.host")
    if value["host"] != settings.host:
        raise ConfigError("config.host must equal BRIDGE_HOST")
    if not isinstance(value["relay_url"], str) or not value["relay_url"]:
        raise ConfigError("config.relay_url must be a non-empty string")
    peers = value.get("peers", {})
    if not isinstance(peers, dict):
        raise ConfigError("config.peers must be an object")
    seen = {}
    normalized = {}
    for host, rooms in peers.items():
        validate_host(host, "peer host")
        if host == settings.host:
            raise ConfigError("config.peers must not include config.host")
        if not isinstance(rooms, list):
            raise ConfigError(f"rooms for peer {host} must be a list")
        normalized[host] = []
        for room in rooms:
            validate_room(room, topology=True, label="peer room")
            folded = room.lower() if room.isascii() else room
            if folded in seen:
                raise ConfigError(
                    f"peer room collision under ASCII case folding: {seen[folded]!r} and {room!r}"
                )
            seen[folded] = room
            normalized[host].append(room)
    channel_config = channels.parse_channels_config(value.get("channels"))
    return Config(value["host"], value["relay_url"], normalized, channel_config)


def validate_post_version(settings):
    path = settings.post_bin
    if not os.path.isfile(path) or not os.access(path, os.X_OK):
        raise ConfigError("POST_BIN must be an existing executable file")
    try:
        result = subprocess.run(
            [path, "--version"],
            env=post_environment(settings.root),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except OSError as error:
        raise ConfigError(f"POST_BIN --version failed: {error}")
    if result.returncode != 0 or result.stdout.strip() != PINNED_POST_VERSION:
        raise ConfigError(
            f"POST_BIN --version must print exactly {PINNED_POST_VERSION!r}"
        )


def validate_repo(settings, config, git):
    branch = git.run(["symbolic-ref", "--quiet", "--short", "HEAD"]).stdout.strip()
    if branch != f"machines/{settings.host}":
        raise ConfigError(f"BRIDGE_REPO must have machines/{settings.host} checked out")
    fetch_url = git.run(["remote", "get-url", "origin"]).stdout.strip()
    push_url = git.run(["remote", "get-url", "--push", "origin"]).stdout.strip()
    if fetch_url != config.relay_url or push_url != config.relay_url:
        raise ConfigError("origin fetch and push URLs must equal config.relay_url")


def run_post_rooms(settings):
    env = post_environment(settings.root)
    result = subprocess.run(
        [settings.post_bin, "rooms", "--json"],
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    if result.returncode != 0:
        raise ConfigError(f"post rooms --json failed: {result.stdout}{result.stderr}")
    value = load_json_bytes(result.stdout.encode("utf-8"), "post rooms output")
    rooms = value.get("rooms") if isinstance(value, dict) else None
    if not isinstance(rooms, list):
        raise ConfigError("post rooms --json returned an unexpected shape")
    result_map = {}
    for room in rooms:
        if (
            not isinstance(room, dict)
            or not isinstance(room.get("name"), str)
            or not isinstance(room.get("path"), str)
        ):
            raise ConfigError("post rooms --json returned an invalid room entry")
        result_map[room["name"]] = room["path"]
    return result_map


def fence_present(settings):
    return (
        destination(settings.root, ".post-arx.json").exists()
        or destination(settings.root, ".post-arx.json").is_symlink()
    )


CHAN_SEEN_MAX_AGE_SECONDS = 30 * 24 * 60 * 60


def reap_chan_seen(settings, logger, now=None):
    """Drop channel dedup markers older than 30 days (SPEC-v2 r5.3).

    ``bridge/chan-seen/<category>/<host>/<sha256>`` is written for every
    ignored or quarantined peer entry and nothing else ever removes it, so
    a peer that keeps publishing junk paths would otherwise own an
    ever-growing slice of this node's inodes.
    """
    root = destination(settings.root, "bridge", "chan-seen")
    if not root.is_dir():
        return 0
    cutoff = (time.time() if now is None else now) - CHAN_SEEN_MAX_AGE_SECONDS
    removed = 0
    for marker in list(root.rglob("*")):
        if marker.is_symlink() or not marker.is_file():
            continue
        try:
            if marker.stat().st_mtime >= cutoff:
                continue
            marker.unlink()
        except OSError:
            continue
        removed += 1
    if removed:
        logger.emit("chan_seen_reaped", count=removed)
    return removed


def recover(settings, git, logger):
    git_dir = Path(git.run(["rev-parse", "--git-dir"]).stdout.strip())
    if not git_dir.is_absolute():
        git_dir = settings.repo / git_dir
    for name in ("rebase-merge", "rebase-apply", "MERGE_HEAD"):
        if (git_dir / name).exists():
            raise TickError(
                "foreign_state",
                f"{name} present in {git_dir}; not ours — inspect manually",
            )
    # bridge/.lock guarantees a single sweeper, so any git lock present at
    # recovery was left by a killed git child (subprocess or unit timeout)
    # and is stale by construction (ruling R4).
    for lock in (git_dir / "index.lock", git_dir / "packed-refs.lock"):
        if lock.exists() or lock.is_symlink():
            lock.unlink()
            logger.emit("git_lock_removed", path=str(lock))
    refs_root = git_dir / "refs"
    if refs_root.is_dir():
        for lock in refs_root.rglob("*.lock"):
            if lock.is_file() or lock.is_symlink():
                lock.unlink()
                logger.emit("git_lock_removed", path=str(lock))
    tmp_root = destination(settings.root, "bridge", "tmp")
    ensure_dir(settings.root, tmp_root)
    for item in list(tmp_root.iterdir()):
        if item.name.endswith(".tmp") and item.is_file() and not item.is_symlink():
            item.unlink()
            logger.emit("tmp_removed", path=str(item))
    bridge_root = destination(settings.root, "bridge")
    for item in bridge_root.rglob(".*.tmp"):
        if item.is_file() and not item.is_symlink():
            item.unlink()
            logger.emit("tmp_removed", path=str(item.relative_to(settings.root)))
    reap_chan_seen(settings, logger)
    for namespace in ("outbox", "receipts", "channels"):
        ensure_dir(settings.repo, destination(settings.repo, namespace))
    for item in settings.repo.rglob(".*.tmp"):
        in_owned_namespace = (
            under(settings.repo / "outbox", item)
            or under(settings.repo / "receipts", item)
            or under(settings.repo / "channels", item)
            or (item.parent == settings.repo and item.name.startswith(".rooms.json."))
        )
        if in_owned_namespace and item.is_file() and not item.is_symlink():
            item.unlink()
            logger.emit("tmp_removed", path=str(item.relative_to(settings.repo)))
    allowed = {".git", "outbox", "receipts", "channels", "rooms.json"}
    stray_root = destination(settings.root, "bridge", "stray")
    for item in list(settings.repo.iterdir()):
        if item.name in allowed:
            continue
        ensure_dir(settings.root, stray_root)
        target = stray_root / f"{int(time.time())}-{item.name}"
        try:
            os.replace(str(item), str(target))
        except OSError as error:
            if error.errno != errno.EXDEV:
                raise
            if item.is_dir() and not item.is_symlink():
                shutil.copytree(item, target, symlinks=True)
                shutil.rmtree(item)
            else:
                shutil.copy2(item, target, follow_symlinks=False)
                item.unlink()
        logger.emit("stray_moved", path=item.name, destination=str(target))


def fast_forward_state(settings, git, logger):
    local = git.rev("HEAD")
    remote_ref = f"origin/machines/{settings.host}"
    remote = git.rev(remote_ref)
    if remote is None:
        return local, None
    if local == remote or git.is_ancestor(remote, local):
        return local, remote
    if git.is_ancestor(local, remote):
        status = git.run(["status", "--porcelain"]).stdout
        if status:
            raise TickError(
                "branch_diverged", "remote advanced while the worktree is dirty"
            )
        git.run(["merge", "--ff-only", remote_ref])
        logger.emit(
            "remote_advanced", local=local, remote=remote
        )
        return git.rev("HEAD"), remote
    raise TickError("branch_diverged")


def refresh_remote_refs(git, logger):
    """Fetch machine refs plus the optional registry branch."""
    machines = git.run(
        [
            "fetch",
            "origin",
            "+refs/heads/machines/*:refs/remotes/origin/machines/*",
        ],
        check=False,
        network=True,
    )
    if machines.returncode != 0:
        return False
    registry = git.run(
        [
            "fetch",
            "origin",
            "+refs/heads/registry:refs/remotes/origin/registry",
        ],
        check=False,
        network=True,
    )
    if registry.returncode != 0:
        output = (registry.stdout + registry.stderr).lower()
        if "couldn't find remote ref" not in output:
            return False
        git.run(["update-ref", "-d", "refs/remotes/origin/registry"], check=False)
        logger.emit("registry_branch_missing")
    return True


def fetch_remote(settings, git, logger):
    """Refresh refs and fast-forward the single-writer local branch."""
    if not refresh_remote_refs(git, logger):
        return False
    fast_forward_state(settings, git, logger)
    return True


def pin_remote_oids(git):
    """Pin every fetched machine tip and the registry tip for this full tick."""
    result = git.run(
        [
            "for-each-ref",
            "--format=%(refname:strip=4) %(objectname)",
            "refs/remotes/origin/machines/*",
        ]
    )
    pinned = {}
    for line in result.stdout.splitlines():
        host, separator, oid = line.partition(" ")
        if separator and host and oid:
            pinned[f"machines/{host}"] = oid
    registry = git.rev("refs/remotes/origin/registry")
    if registry is not None:
        pinned["registry"] = registry
    return pinned


def parse_envelope(data, expected_id, expected_room, logger=None):
    separator = data.find(b"\n---\n")
    if separator < 0:
        raise ConfigError("malformed_header: missing envelope separator")
    if separator > 4096:
        raise ConfigError("malformed_header: header exceeds 4 KiB")
    try:
        value = load_json_bytes(data[:separator], "mail envelope")
    except ConfigError as error:
        raise ConfigError(f"malformed_header: {error}")
    if not isinstance(value, dict):
        raise ConfigError("malformed_header: envelope must be an object")
    missing = ENVELOPE_REQUIRED - set(value)
    if missing:
        raise ConfigError(
            "malformed_header: missing {}".format(",".join(sorted(missing)))
        )
    for key in ENVELOPE_REQUIRED:
        if not isinstance(value[key], str):
            raise ConfigError(f"malformed_header: {key} must be a string")
    for key in ENVELOPE_OPTIONAL:
        if key in value and not isinstance(value[key], str):
            raise ConfigError(f"malformed_header: {key} must be a string")
    validate_attribution(value, MAIL_ADDRESS_KINDS)
    validate_id(value["id"], "envelope id")
    validate_room(value["from"], label="envelope from")
    validate_room(value["to"], label="envelope to")
    if value["id"] != expected_id:
        raise ConfigError("id_mismatch")
    if value["to"] != expected_room:
        raise ConfigError("to_mismatch")
    if not workspace_addressed(value):
        # r5.4: lineage and participant addresses are host-local; `to` names
        # a lineage or participant, not a room, so this must never land in a
        # room inbox.
        raise ConfigError("unsupported_address_kind")
    if value["kind"] not in MAIL_KINDS:
        raise ConfigError("invalid_kind")
    if len(value["subject"].encode("utf-8")) > 1024:
        raise ConfigError("subject_too_large")
    try:
        dt.datetime.strptime(value["sent"], "%Y-%m-%d %H:%M:%S %z")
    except ValueError:
        raise ConfigError("invalid_sent")
    unknown = set(value) - ENVELOPE_REQUIRED - ENVELOPE_OPTIONAL
    if unknown and logger is not None:
        logger.emit("unknown_envelope_keys", id=expected_id, keys=sorted(unknown))
    return value


def receipt_bytes(status, host, room, mail_id, sha256, reason):
    value = {
        "v": 1,
        "status": status,
        "host": host,
        "room": room,
        "id": mail_id,
        "sha256": sha256,
        "reason": reason,
        "at": utc_now(),
    }
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode(
        "utf-8"
    )


def write_receipt(settings, host, room, mail_id, status, sha256, reason, logger):
    if fence_present(settings):
        raise TickError("fenced")
    path = destination(settings.repo, "receipts", host, room, mail_id + ".json")
    payload = receipt_bytes(status, host, room, mail_id, sha256, reason)
    existing = None
    try:
        existing = open_regular(path, 4096)
    except FileNotFoundError:
        pass
    if existing is not None:
        try:
            value = load_json_bytes(existing, str(path))
        except ConfigError:
            value = None
        if isinstance(value, dict) and all(
            (
                value.get("v") == 1,
                value.get("status") == status,
                value.get("host") == host,
                value.get("room") == room,
                value.get("id") == mail_id,
                value.get("sha256") == sha256,
                value.get("reason") == reason,
            )
        ):
            return
    if existing != payload:
        atomic_replace(path, payload, settings.repo)
        logger.emit(
            "receipt", status=status, host=host, room=room, id=mail_id, reason=reason
        )


def forensic_copy(settings, host, room, mail_id, data, suffix, logger):
    if fence_present(settings):
        raise TickError("fenced")
    path = destination(
        settings.root,
        "bridge",
        "quarantine",
        host,
        room,
        mail_id + suffix,
    )
    try:
        exclusive_publish(
            path, data, destination(settings.root, "bridge", "tmp"), settings.root
        )
    except FileExistsError:
        try:
            if open_regular(path, settings.max_mail_bytes) != data:
                conflict = path.with_name(mail_id + f"-{host}-conflict.mail")
                exclusive_publish(
                    conflict,
                    data,
                    destination(settings.root, "bridge", "tmp"),
                    settings.root,
                )
        except (FileExistsError, ConfigError):
            pass
    logger.emit("forensic", host=host, room=room, id=mail_id, path=str(path))


def forensic_note(settings, host, room, mail_id, reason, entry, logger):
    if fence_present(settings):
        raise TickError("fenced")
    path = destination(
        settings.root,
        "bridge",
        "quarantine",
        host,
        room,
        mail_id + ".json",
    )
    note = {
        "host": host,
        "room": room,
        "id": mail_id,
        "reason": reason,
        "path": entry["path"],
        "mode": entry["mode"],
        "size": entry["size"],
        "object": entry["object"],
        "at": utc_now(),
    }
    atomic_replace(
        path,
        (json.dumps(note, sort_keys=True) + "\n").encode("utf-8"),
        settings.root,
    )
    logger.emit("forensic", host=host, room=room, id=mail_id, path=str(path))


def forensic_path_note(settings, host, entry, reason, logger):
    if fence_present(settings):
        raise TickError("fenced")
    fingerprint = hashlib.sha256(entry["path"].encode("utf-8")).hexdigest()
    path = destination(
        settings.root,
        "bridge",
        "quarantine",
        host,
        "_paths",
        fingerprint + ".json",
    )
    note = {
        "host": host,
        "reason": reason,
        "path": entry["path"],
        "mode": entry["mode"],
        "size": entry["size"],
        "object": entry["object"],
        "at": utc_now(),
    }
    atomic_replace(
        path,
        (json.dumps(note, sort_keys=True) + "\n").encode(),
        settings.root,
    )
    logger.emit("forensic", host=host, id=fingerprint, path=str(path))


def forensic_invalid_path_note(settings, host, entry, logger):
    if fence_present(settings):
        raise TickError("fenced")
    raw_path = entry["raw_path"]
    fingerprint = hashlib.sha256(raw_path).hexdigest()
    path = destination(
        settings.root,
        "bridge",
        "quarantine",
        host,
        "_paths",
        fingerprint + ".json",
    )
    note = {
        "host": host,
        "reason": "invalid_utf8",
        "path_sha256": fingerprint,
        "path_hex": raw_path.hex(),
        "mode": entry["mode"],
        "size": entry["size"],
        "object": entry["object"],
        "at": utc_now(),
    }
    atomic_replace(
        path,
        (json.dumps(note, sort_keys=True) + "\n").encode(),
        settings.root,
    )
    logger.emit("forensic", host=host, id=fingerprint, path=str(path))
    return fingerprint


def unread_descriptor_sha(host, entry):
    descriptor = f"{host}/{entry['path']}@{entry['object']}"
    return hashlib.sha256(descriptor.encode("utf-8")).hexdigest()


def quarantine(
    settings, host, room, mail_id, sha256, reason, data, logger, conflict=False
):
    if data is not None:
        suffix = f"-{host}-conflict.mail" if conflict else ".mail"
        forensic_copy(settings, host, room, mail_id, data, suffix, logger)
    write_receipt(settings, host, room, mail_id, "quarantined", sha256, reason, logger)
    logger.emit("quarantined", host=host, room=room, id=mail_id, reason=reason)


def local_collision(settings, host, room, mail_id, sha256):
    delivered_root = destination(settings.root, "bridge", "delivered")
    if delivered_root.exists():
        for other in delivered_root.glob(f"*/*/{mail_id}"):
            if other != destination(delivered_root, host, room, mail_id):
                return True
    ledger = destination(settings.root, "bridge", "delivered", host, room, mail_id)
    try:
        stored = open_regular(ledger, 65).decode("ascii").strip()
        if stored != sha256:
            return True
    except FileNotFoundError:
        pass
    except (ConfigError, UnicodeDecodeError):
        return True
    copies = [
        destination(settings.root, "archive", mail_id + ".mail"),
        destination(settings.root, room, "inbox", mail_id + ".mail"),
        destination(settings.root, room, "read", mail_id + ".mail"),
    ]
    for path in copies:
        try:
            if (
                hashlib.sha256(open_regular(path, settings.max_mail_bytes)).hexdigest()
                != sha256
            ):
                return True
        except FileNotFoundError:
            pass
        except ConfigError:
            return True
    reservation = destination(settings.root, "bridge", "received", mail_id)
    try:
        reserved = open_regular(reservation, 256).decode("ascii").strip()
    except FileNotFoundError:
        reserved = ""
    except (ConfigError, UnicodeDecodeError):
        return True
    # Durable collision reservation (SPEC r3.5 I3(c)/I6): present with a
    # different (host, room) or sha means another K owns this id; the same
    # triple means resume. An empty marker (pre-S2 test runs only) claims
    # nothing and is refreshed at the publish step.
    return bool(reserved) and reserved != f"{host}/{room} {sha256}"


def publish_marker(settings, path, content=b"", temp_subdir="tmp"):
    try:
        exclusive_publish(
            path,
            content,
            destination(settings.root, "bridge", temp_subdir),
            settings.root,
        )
    except FileExistsError:
        return False
    return True


def process_inbound(
    settings, config, git, real_rooms, placeholders, logger, snapshot=None, holds=None
):
    held = 0
    quarantined = 0
    if holds is None:
        holds = HoldLedger(settings.root, "held-not-homed")
    post_rooms = snapshot.post_rooms if snapshot is not None else None
    peer_hosts = snapshot.peers if snapshot is not None else sorted(config.peers)
    for host in peer_hosts:
        git.deadline.check()
        ref = (
            snapshot.oids.get(f"machines/{host}")
            if snapshot is not None
            else git.rev(f"origin/machines/{host}")
        )
        if ref is None:
            logger.emit("peer_branch_missing", host=host)
            continue
        try:
            entries = git.ls_tree(ref, f"outbox/{settings.host}/")
        except GitReadError as error:
            note_git_failure(git, logger, host, error)
            continue
        for entry in entries:
            git.deadline.check()
            if entry["path"] is None:
                fingerprint = forensic_invalid_path_note(
                    settings, host, entry, logger
                )
                logger.emit(
                    "quarantined_path",
                    host=host,
                    id=fingerprint,
                    reason="invalid_utf8",
                )
                continue
            path = PurePosixPath(entry["path"])
            parts = path.parts
            if len(parts) != 4 or parts[0] != "outbox" or parts[1] != settings.host:
                forensic_path_note(settings, host, entry, "invalid_path", logger)
                logger.emit(
                    "quarantined_path",
                    host=host,
                    path=entry["path"],
                    reason="invalid_path",
                )
                continue
            room = parts[2]
            filename = parts[3]
            try:
                validate_room(room, topology=True, label="outbox room")
                if not filename.endswith(".mail"):
                    raise ConfigError("outbox filename must end in .mail")
                mail_id = filename[:-5]
                validate_id(mail_id)
            except ConfigError as error:
                note_id = hashlib.sha256(entry["path"].encode("utf-8")).hexdigest()[:22]
                forensic_path_note(settings, host, entry, str(error), logger)
                logger.emit(
                    "quarantined_path",
                    host=host,
                    path=entry["path"],
                    id=note_id,
                    reason=str(error),
                )
                continue
            if entry["mode"] != "100644" or entry["type"] != "blob":
                reason = "non-regular-object"
                sha256 = unread_descriptor_sha(host, entry)
                forensic_note(settings, host, room, mail_id, reason, entry, logger)
                write_receipt(
                    settings,
                    host,
                    room,
                    mail_id,
                    "quarantined",
                    sha256,
                    reason,
                    logger,
                )
                logger.emit(
                    "quarantined", host=host, room=room, id=mail_id, reason=reason
                )
                quarantined += 1
                continue
            if entry["size"] is None or entry["size"] > settings.max_mail_bytes:
                reason = "oversize-unread"
                sha256 = unread_descriptor_sha(host, entry)
                forensic_note(settings, host, room, mail_id, reason, entry, logger)
                write_receipt(
                    settings,
                    host,
                    room,
                    mail_id,
                    "quarantined",
                    sha256,
                    reason,
                    logger,
                )
                logger.emit(
                    "quarantined", host=host, room=room, id=mail_id, reason=reason
                )
                quarantined += 1
                continue
            data = git.show(ref, entry["path"])
            if (
                data is None
                or len(data) != entry["size"]
                or len(data) > settings.max_mail_bytes
            ):
                reason = "unreadable-object"
                sha256 = unread_descriptor_sha(host, entry)
                forensic_note(settings, host, room, mail_id, reason, entry, logger)
                quarantine(
                    settings,
                    host,
                    room,
                    mail_id,
                    sha256,
                    reason,
                    None,
                    logger,
                )
                quarantined += 1
                continue
            sha256 = hashlib.sha256(data).hexdigest()
            if room not in real_rooms:
                quarantine(
                    settings,
                    host,
                    room,
                    mail_id,
                    sha256,
                    "unknown_room",
                    data,
                    logger,
                )
                quarantined += 1
                continue
            try:
                envelope = parse_envelope(data, mail_id, room, logger)
            except ConfigError as error:
                quarantine(
                    settings, host, room, mail_id, sha256, str(error), data, logger
                )
                quarantined += 1
                checkpoint("inbound-i1")
                continue
            checkpoint("inbound-i1")
            sender = envelope["from"]
            verdict = (
                binding_verdict(snapshot, host, sender)
                if snapshot is not None
                else (
                    FORGED_SELF
                    if sender in real_rooms
                    or (sender in placeholders and placeholders[sender] != host)
                    else UNHOMED
                    if sender not in placeholders
                    else "verified"
                )
            )
            if verdict in (FORGED_SELF, NAME_COLLISION, UNPUBLISHED_SENDER):
                # SPEC-v2 §What this changes in v1 mail: the reason is the
                # verdict. It never depends on whether a registry branch is
                # fetchable this tick (review D3).
                quarantine(
                    settings, host, room, mail_id, sha256, verdict, data, logger
                )
                quarantined += 1
                checkpoint("inbound-i2")
                continue
            ledger = destination(
                settings.root, "bridge", "delivered", host, room, mail_id
            )
            try:
                stored_sha = open_regular(ledger, 65).decode("ascii").strip()
            except (FileNotFoundError, ConfigError, UnicodeDecodeError):
                stored_sha = None
            # SPEC r3.5 I3½: a ledger hit with the matching sha replays — it
            # skips ONLY the route evaluation below; fence rechecks and state
            # repair still run (receipts move held→delivered, never back).
            replay = stored_sha == sha256
            # r5.5 (M2): deliver on the evidence post consumes. These checks
            # run only for a first delivery; a replay keeps its outcome.
            if not replay and verdict == VERIFIED and not post_sees_remote(
                settings.root, host, sender, post_rooms
            ):
                # post would not read this sender as remote: hold without a
                # receipt, so the bytes stay on the peer branch and every
                # full tick retries.
                holds.hold(host, room, mail_id)
                logger.emit(
                    "held",
                    host=host,
                    room=room,
                    id=mail_id,
                    sender=sender,
                    reason=SENDER_NOT_HOMED,
                )
                checkpoint("inbound-i2")
                continue
            if (
                not replay
                and verdict == UNHOMED
                and envelope.get("from_participant") is not None
            ):
                # No remote-origin evidence reaches post for an unhomed
                # sender, so a participant stamp would read as local.
                quarantine(
                    settings,
                    host,
                    room,
                    mail_id,
                    sha256,
                    REMOTE_PARTICIPANT_UNHOMED,
                    data,
                    logger,
                )
                quarantined += 1
                checkpoint("inbound-i2")
                continue
            if verdict == UNHOMED:
                logger.emit(
                    "from-unhomed", host=host, room=room, id=mail_id, sender=sender
                )
            checkpoint("inbound-i2")
            if local_collision(settings, host, room, mail_id, sha256):
                quarantine(
                    settings,
                    host,
                    room,
                    mail_id,
                    sha256,
                    "id-collision",
                    data,
                    logger,
                    conflict=True,
                )
                quarantined += 1
                checkpoint("inbound-i3")
                continue
            checkpoint("inbound-i3")
            if fence_present(settings):
                raise TickError("fenced")
            checkpoint("inbound-i4")
            if not replay:
                rules = load_rules(settings)
                reason = blocked_reason(rules, sender, room)
                if reason is not None:
                    write_receipt(
                        settings, host, room, mail_id, "held", sha256, reason, logger
                    )
                    logger.emit(
                        "held", host=host, room=room, id=mail_id, reason=reason
                    )
                    held += 1
                    checkpoint("inbound-i5")
                    continue
            checkpoint("inbound-i5")
            if fence_present(settings):
                raise TickError("fenced")
            reservation = destination(settings.root, "bridge", "received", mail_id)
            # First write of every delivery: the durable collision reservation
            # `<host>/<room> <sha>` consulted by local_collision at I3(c), and
            # still the bridge-origin exclusion for outbound selection.
            reservation_content = f"{host}/{room} {sha256}\n".encode("ascii")
            if not publish_marker(settings, reservation, reservation_content):
                try:
                    if open_regular(reservation, 32) == b"":
                        atomic_replace(
                            reservation, reservation_content, settings.root
                        )
                except (ConfigError, OSError):
                    pass
            checkpoint("inbound-received")
            room_path = destination(settings.root, room)
            ensure_dir(settings.root, destination(room_path, "inbox"))
            ensure_dir(settings.root, destination(room_path, "read"))
            inbox = destination(room_path, "inbox", mail_id + ".mail")
            read = destination(room_path, "read", mail_id + ".mail")
            archive = destination(settings.root, "archive", mail_id + ".mail")
            inbox_present = inbox.exists() or inbox.is_symlink()
            read_present = read.exists() or read.is_symlink()
            archive_present = archive.exists() or archive.is_symlink()
            if not inbox_present and not read_present and archive_present:
                logger.emit("archive-only", host=host, room=room, id=mail_id)
            if not inbox_present and not read_present and not archive_present:
                if fence_present(settings):
                    raise TickError("fenced")
                if replay:
                    logger.emit(
                        "ledger_only_repaired",
                        host=host,
                        room=room,
                        id=mail_id,
                    )
                try:
                    exclusive_publish(
                        inbox,
                        data,
                        destination(settings.root, "bridge", "tmp"),
                        settings.root,
                    )
                    logger.emit("inbox_delivered", host=host, room=room, id=mail_id)
                except FileExistsError:
                    if local_collision(settings, host, room, mail_id, sha256):
                        quarantine(
                            settings,
                            host,
                            room,
                            mail_id,
                            sha256,
                            "id-collision",
                            data,
                            logger,
                            conflict=True,
                        )
                        quarantined += 1
                        continue
            checkpoint("inbound-i6")
            if not archive_present:
                if fence_present(settings):
                    raise TickError("fenced")
                try:
                    exclusive_publish(
                        archive,
                        data,
                        destination(settings.root, "bridge", "tmp"),
                        settings.root,
                    )
                    logger.emit("archive_delivered", host=host, room=room, id=mail_id)
                except FileExistsError:
                    if (
                        hashlib.sha256(
                            open_regular(archive, settings.max_mail_bytes)
                        ).hexdigest()
                        != sha256
                    ):
                        quarantine(
                            settings,
                            host,
                            room,
                            mail_id,
                            sha256,
                            "id-collision",
                            data,
                            logger,
                            conflict=True,
                        )
                        quarantined += 1
                        continue
            checkpoint("inbound-i7")
            ledger = destination(
                settings.root, "bridge", "delivered", host, room, mail_id
            )
            publish_marker(settings, ledger, (sha256 + "\n").encode("ascii"))
            checkpoint("inbound-i8")
            write_receipt(
                settings, host, room, mail_id, "delivered", sha256, "", logger
            )
            logger.emit("delivered", host=host, room=room, id=mail_id, sha256=sha256)
            checkpoint("inbound-i9")
        # The host's outbox was walked in full: stamps for mail it no longer
        # holds (delivered, quarantined, withdrawn) are dropped.
        holds.settle(host)
    return held, quarantined


def mail_age_seconds(mail_id):
    try:
        moment = dt.datetime.strptime(mail_id[:15], "%Y%m%d-%H%M%S").replace(
            tzinfo=dt.timezone.utc
        )
        return max(0, int((dt.datetime.now(dt.timezone.utc) - moment).total_seconds()))
    except ValueError:
        return None


def marker_exists(settings, namespace, mail_id):
    # Presence-only checks for outbound selection and prune gating. The
    # `received/<id>` reservation's *content* is read only by local_collision.
    return destination(settings.root, "bridge", namespace, mail_id).exists()


def delivered_id_exists(settings, mail_id):
    root = destination(settings.root, "bridge", "delivered")
    return root.exists() and any(root.glob(f"*/*/{mail_id}"))


def select_outbound(
    settings, config, real_rooms, placeholders, logger, deadline, snapshot=None
):
    selected = []
    unrelayable = []
    archive_root = destination(settings.root, "archive")
    if not archive_root.is_dir():
        checkpoint("outbound-o1-select")
        return selected, unrelayable
    for path in sorted(archive_root.iterdir()):
        deadline.check()
        if path.suffix != ".mail":
            continue
        mail_id = path.stem
        try:
            validate_id(mail_id)
        except ConfigError as error:
            logger.emit("outbound_ignored", id=mail_id, reason=str(error))
            unrelayable.append(mail_id)
            continue
        if marker_exists(settings, "received", mail_id) or delivered_id_exists(
            settings, mail_id
        ):
            continue
        if marker_exists(settings, "published", mail_id):
            continue
        try:
            data = open_regular(path, settings.max_mail_bytes)
            envelope = parse_outbound_envelope(data, mail_id, logger)
        except (ConfigError, OSError) as error:
            logger.emit("outbound_ignored", id=mail_id, reason=str(error))
            unrelayable.append(mail_id)
            continue
        if envelope is None:
            continue
        recipient = envelope["to"]
        sender = envelope["from"]
        if snapshot is not None:
            host = snapshot.route_for(recipient)
            if host is None:
                # r5.3 §Names fold: `contested` is keyed by the ASCII
                # case-fold; `recipient` is the envelope's display spelling.
                if snapshot.contested.get(fold_name(recipient)) is not None:
                    logger.emit(
                        "route_contested",
                        room=recipient,
                        id=mail_id,
                        age_seconds=mail_age_seconds(mail_id),
                    )
                continue
        else:
            host = placeholders.get(recipient)
        if host is None:
            continue
        if (
            sender in snapshot.placeholders
            if snapshot is not None
            else sender in placeholders
        ):
            continue
        selected.append((path, host, recipient, mail_id, data))
    checkpoint("outbound-o1-select")
    return selected, unrelayable[:20]


def workspace_addressed(value):
    return value.get("address_kind", "workspace") == "workspace"


def parse_outbound_envelope(data, expected_id, logger):
    """Parse an archive envelope for relay; None when it is not room mail.

    r5.4: `send --to lineage:<n>` / `participant:<id>` archive with `to` set
    to the bare lineage name or participant id. Such mail is host-local and
    is skipped before routing, so a peer room of the same name never gets it.
    """
    separator = data.find(b"\n---\n")
    if separator < 0 or separator > 4096:
        raise ConfigError("malformed_header")
    value = load_json_bytes(data[:separator], "mail envelope")
    if not isinstance(value, dict) or not ENVELOPE_REQUIRED.issubset(value):
        raise ConfigError("malformed_header")
    if not workspace_addressed(value):
        return None
    recipient = value.get("to")
    return parse_envelope(data, expected_id, recipient, logger)


def copy_outbound(settings, selected, logger):
    for archive, host, room, mail_id, data in selected:
        target = destination(settings.repo, "outbox", host, room, mail_id + ".mail")
        try:
            existing = open_regular(target, settings.max_mail_bytes)
        except FileNotFoundError:
            existing = None
        if existing is not None:
            if existing != data:
                raise ConfigError(
                    f"outbox differs from immutable archive for {mail_id}"
                )
            continue
        try:
            exclusive_publish(target, data, target.parent, settings.repo)
        except FileExistsError:
            if open_regular(target, settings.max_mail_bytes) != data:
                raise ConfigError(f"outbox collision for {mail_id}")
        logger.emit(
            "outbound_copied", host=host, room=room, id=mail_id, archive=str(archive)
        )
        checkpoint("outbound-o2-copy")


def parse_receipt(data, expected_host, expected_room, expected_id, expected_sha):
    value = load_json_bytes(data, "receipt")
    if not isinstance(value, dict) or set(value) != RECEIPT_KEYS:
        raise ConfigError("receipt has wrong keys")
    if value["v"] != 1 or value["status"] not in RECEIPT_STATUSES:
        raise ConfigError("receipt version or status is invalid")
    for key in ("host", "room", "id", "sha256", "reason", "at"):
        if not isinstance(value[key], str):
            raise ConfigError(f"receipt {key} must be a string")
    if (
        value["host"] != expected_host
        or value["room"] != expected_room
        or value["id"] != expected_id
    ):
        raise ConfigError("receipt path fields do not match")
    if SHA256_RE.fullmatch(value["sha256"]) is None or value["sha256"] != expected_sha:
        raise ConfigError("receipt sha256 does not match outbox")
    return value


def prune_outbox(settings, config, git, logger, snapshot=None):
    root = destination(settings.repo, "outbox")
    if not root.exists():
        checkpoint("outbound-o5-prune")
        return 0
    pruned = 0
    for path in sorted(root.glob("*/*/*.mail")):
        relative = path.relative_to(settings.repo).as_posix()
        parts = PurePosixPath(relative).parts
        if len(parts) != 4:
            continue
        host, room, filename = parts[1], parts[2], parts[3]
        if not filename.endswith(".mail"):
            logger.emit("outbox_invalid", path=relative)
            continue
        mail_id = filename[:-5]
        if not marker_exists(settings, "published", mail_id):
            continue
        try:
            validate_id(mail_id)
            data = open_regular(path, settings.max_mail_bytes)
        except (ConfigError, FileNotFoundError) as error:
            logger.emit("outbox_invalid", path=relative, reason=str(error))
            continue
        sha256 = hashlib.sha256(data).hexdigest()
        ref = (
            snapshot.oids.get(f"machines/{host}")
            if snapshot is not None
            else f"origin/machines/{host}"
        )
        if ref is None:
            continue
        receipt_path = f"receipts/{settings.host}/{room}/{mail_id}.json"
        try:
            listed = git.ls_tree(ref, receipt_path)
        except GitReadError as error:
            note_git_failure(git, logger, host, error)
            continue
        matches = [entry for entry in listed if entry["path"] == receipt_path]
        if len(matches) != 1:
            continue
        entry = matches[0]
        if (
            entry["mode"] != "100644"
            or entry["type"] != "blob"
            or entry["size"] is None
            or entry["size"] > 4096
        ):
            logger.emit(
                "receipt_ignored",
                host=host,
                room=room,
                id=mail_id,
                reason="invalid_mode_or_size",
            )
            continue
        try:
            receipt_data = git.show(ref, receipt_path)
            if (
                receipt_data is None
                or len(receipt_data) != entry["size"]
                or len(receipt_data) > 4096
            ):
                raise ConfigError("unreadable-object")
            receipt = parse_receipt(
                receipt_data, settings.host, room, mail_id, sha256
            )
        except ConfigError as error:
            logger.emit(
                "receipt_ignored", host=host, room=room, id=mail_id, reason=str(error)
            )
            continue
        if receipt["status"] != "delivered":
            logger.emit(
                "outbound_waiting",
                host=host,
                room=room,
                id=mail_id,
                status=receipt["status"],
                reason=receipt["reason"],
                age_seconds=mail_age_seconds(mail_id),
            )
            continue
        git.run(["rm", "--quiet", "--", relative])
        pruned += 1
        logger.emit("outbox_pruned", host=host, room=room, id=mail_id)
        checkpoint("outbound-o5-prune")
    checkpoint("outbound-o5-prune")
    return pruned



def queued_work(settings, git):
    remote_ref = f"origin/machines/{settings.host}"
    remote = git.rev(remote_ref)
    if remote is None:
        return True
    local_ahead = git.rev("HEAD") != remote
    commands = (
        ["diff", "--name-only", "-z", remote_ref, "HEAD", "--", "outbox", "receipts", "channels", "rooms.json"],
        ["diff", "--name-only", "-z", "--", "outbox", "receipts", "channels", "rooms.json"],
        ["diff", "--cached", "--name-only", "-z", "--", "outbox", "receipts", "channels", "rooms.json"],
        ["ls-files", "--others", "--exclude-standard", "-z", "--", "outbox", "receipts", "channels", "rooms.json"],
    )
    changed = set()
    for command in commands:
        result = git.run(command, check=False, text=False)
        if result.returncode != 0:
            return True
        for raw_path in result.stdout.split(b"\0"):
            if not raw_path:
                continue
            try:
                changed.add(raw_path.decode("utf-8"))
            except UnicodeDecodeError:
                return True
    # Ruling R3: unpushed receipts of EVERY status are queued work — held
    # included (the sender cannot see the hold until the receipt lands).
    return local_ahead or bool(changed)


def commit_and_push(settings, config, git, rooms, logger, has_queued_work):
    ensure_dir(settings.repo, destination(settings.repo, "outbox"))
    ensure_dir(settings.repo, destination(settings.repo, "receipts"))
    ensure_dir(settings.repo, destination(settings.repo, "channels"))
    git.run(["add", "-A", "--", "outbox", "receipts", "channels", "rooms.json"])
    checkpoint("outbound-o3-stage")
    changed = git.run(["diff", "--cached", "--quiet"], check=False).returncode != 0
    if changed:
        git.run(
            [
                "-c",
                "user.name=post-bridge",
                "-c",
                f"user.email=post-bridge@{settings.host}",
                "commit",
                "-m",
                f"post-bridge: {settings.host} tick {utc_now()}",
            ]
        )
        logger.emit("committed", head=git.rev("HEAD"))
        checkpoint("after-commit")
    local = git.rev("HEAD")
    remote_ref = f"origin/machines/{settings.host}"
    remote = git.rev(remote_ref)
    pushed = False
    if remote != local:
        result = git.run(
            ["push", "origin", f"HEAD:refs/heads/machines/{settings.host}"],
            check=False,
            network=True,
        )
        if result.returncode != 0:
            output = result.stdout + result.stderr
            refreshed_ok = refresh_remote_refs(git, logger)
            refreshed = git.rev(remote_ref) if refreshed_ok else remote
            if (
                "rejected" in output.lower()
                or "non-fast-forward" in output.lower()
                or (refreshed is not None and not git.is_ancestor(refreshed, local))
            ):
                raise TickError("branch_diverged", output)
            logger.emit("push_failed", queued_work=has_queued_work)
            if has_queued_work:
                raise TickError("push_failed", output)
            return False
        pushed = True
        # The crash checkpoint sits at the instant the push subprocess
        # returned success — before any derivation (finding 4): a hard kill
        # here leaves the marker absent and the next tick's step-0 derivation
        # reconstructs it from the fetched tree.
        checkpoint("after-push")
        derive_published_and_tidy(
            settings, config, git, rooms, logger, "HEAD", tidy=True
        )
        checkpoint("after-derive")
        if git.rev(remote_ref) != local:
            refreshed_ok = refresh_remote_refs(git, logger)
            if not refreshed_ok:
                logger.emit("fetch", ok=False, reason="post_push_fetch_failed")
                git.run(
                    [
                        "update-ref",
                        f"refs/remotes/origin/machines/{settings.host}",
                        local,
                    ]
                )
            elif git.rev(remote_ref) != local:
                raise TickError("branch_diverged", "remote changed after successful push")
        logger.emit("pushed", head=local, ref=f"machines/{settings.host}")
    return pushed


def derive_published_and_tidy(settings, config, git, rooms, logger, ref, tidy):
    head = git.rev(ref)
    if head is None:
        return 0
    count = 0
    for entry in git.ls_tree(ref, "outbox/"):
        if entry["path"] is None:
            continue
        parts = PurePosixPath(entry["path"]).parts
        if len(parts) != 4 or parts[0] != "outbox" or not parts[3].endswith(".mail"):
            continue
        host, room, filename = parts[1], parts[2], parts[3]
        mail_id = filename[:-5]
        try:
            validate_id(mail_id)
        except ConfigError:
            continue
        marker = destination(settings.root, "bridge", "published", mail_id)
        created = publish_marker(settings, marker, (head + "\n").encode("ascii"))
        if created:
            logger.emit("published", host=host, room=room, id=mail_id, head=head)
            count += 1
        checkpoint("outbound-o4-published")
        if not tidy:
            continue
        if room in rooms:
            room_root = destination(settings.root, room)
            for directory_name in ("inbox", "read"):
                artifact = destination(room_root, directory_name, mail_id + ".mail")
                try:
                    metadata = artifact.lstat()
                except FileNotFoundError:
                    continue
                if stat.S_ISREG(metadata.st_mode) and under(settings.root, artifact):
                    artifact.unlink()
                    fsync_directory(artifact.parent)
                    logger.emit(
                        "placeholder_tidied",
                        room=room,
                        id=mail_id,
                        store=directory_name,
                    )
        checkpoint("outbound-o4-tidy")
    return count


def read_health(settings):
    path = destination(settings.root, "bridge", "health.json")
    try:
        value = load_json_bytes(open_regular(path, 64 * 1024), str(path))
        return value if isinstance(value, dict) else {}
    except (FileNotFoundError, ConfigError):
        return {}


@contextmanager
def health_lock(root, required):
    # Serializes health.json read-modify-writes across the tick holder and
    # busy probes (SPEC r3.5.1 Health). The installer creates the lock file;
    # the sweeper never does (no O_CREAT). On the fatal-config path a missing
    # lock means write health.json unlocked rather than create a file; on
    # every live path a missing lock is a misinstall and propagates.
    path = destination(root, "bridge", ".health.lock")
    try:
        descriptor = os.open(str(path), os.O_RDWR | getattr(os, "O_NOFOLLOW", 0))
    except FileNotFoundError:
        if required:
            raise
        descriptor = None
    try:
        if descriptor is not None:
            fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        if descriptor is not None:
            os.close(descriptor)


def bounded_git_failures(value):
    # m6: health carries at most 20 git read failures, each {host, ref, path}
    # with string fields; anything else from a prior file is dropped.
    if not isinstance(value, list):
        return []
    kept = []
    for item in value:
        if isinstance(item, dict) and all(
            isinstance(item.get(key), str) for key in ("host", "ref", "path")
        ):
            kept.append({key: item[key] for key in ("host", "ref", "path")})
    return kept[:20]


def bounded_hold_summary(value):
    # r5.5 (M2) / m7: {host: {count, oldest_age_seconds}} with integer
    # fields; anything else from a prior file is dropped.
    if not isinstance(value, dict):
        return {}
    kept = {}
    for host, item in value.items():
        if (
            isinstance(host, str)
            and isinstance(item, dict)
            and all(
                isinstance(item.get(key), int) and not isinstance(item.get(key), bool)
                for key in ("count", "oldest_age_seconds")
            )
        ):
            kept[host] = {
                "count": item["count"],
                "oldest_age_seconds": item["oldest_age_seconds"],
            }
    return kept


def write_health(
    settings,
    ok,
    reason,
    *,
    held=None,
    quarantined=None,
    outbound_unrelayable=None,
    fetch_ok=None,
    push_ok=None,
    room_stats=None,
    channel_stats=None,
    git_failed=None,
    sender_not_homed=None,
    quiet=False,
):
    # Every health.json write is a read-modify-write under .health.lock, and
    # every carried field comes only from the prior read taken under that
    # lock (SPEC r3.5.1 Health). None carries the prior value; fetch_ok /
    # push_ok True stamp last_fetch_ok / last_push_ok = now, anything else
    # carries the prior stamp. Fetch staleness is decided here, inside the
    # lock, from the locked prior, and never overrides a caller-supplied
    # unhealthy reason: every `ok and ...` test below is skipped once ok is
    # false. SPEC-v2 §Health removed `undeliverable`; the key is gone from
    # every writer.
    with health_lock(settings.root, required=True):
        prior = read_health(settings)
        now = utc_now()
        first_tick_at = prior.get("first_tick_at")
        if epoch_from_iso(first_tick_at) is None:
            first_tick_at = now
        last_fetch_ok = now if fetch_ok is True else prior.get("last_fetch_ok")
        last_push_ok = now if push_ok is True else prior.get("last_push_ok")
        if held is None:
            held = prior.get("held", 0)
        if quarantined is None:
            quarantined = prior.get("quarantined", 0)
        if outbound_unrelayable is None:
            outbound_unrelayable = prior.get("outbound_unrelayable", [])
        if room_stats is None:
            room_stats = prior.get(
                "rooms",
                {"published": 0, "collisions": [], "retired": [], "route_contested": 0},
            )
        if channel_stats is None:
            channel_stats = prior.get(
                "channels",
                {
                    "imported": 0,
                    "published": 0,
                    "quarantined": 0,
                    "unpublishable": 0,
                    "diverged": [],
                    "rewritten": [],
                },
            )
        if git_failed is None:
            git_failed = prior.get("git_failed", [])
        git_failed = bounded_git_failures(git_failed)
        if sender_not_homed is None:
            sender_not_homed = prior.get("sender_not_homed", {})
        sender_not_homed = bounded_hold_summary(sender_not_homed)
        if ok and git_failed:
            ok, reason = False, "git_failed"
        if ok and room_stats.get("collisions"):
            ok, reason = False, "room_name_collision"
        if ok and channel_stats.get("diverged"):
            ok, reason = False, "channel_diverged"
        if ok and channel_stats.get("rewritten"):
            ok, reason = False, "relay_history_rewritten"
        if not isinstance(outbound_unrelayable, list):
            outbound_unrelayable = []
        outbound_unrelayable = [
            mail_id for mail_id in outbound_unrelayable if isinstance(mail_id, str)
        ][:20]
        if ok and fetch_ok is False:
            anchor = epoch_from_iso(last_fetch_ok) or epoch_from_iso(first_tick_at)
            if (
                anchor is None
                or time.time() - anchor > settings.fetch_grace_seconds
            ):
                ok, reason = False, "fetch_stale"
        stalled_since = None if ok else prior.get("stalled_since") or now
        value = {
            "ts": now,
            "ok": bool(ok),
            "reason": reason,
            "first_tick_at": first_tick_at,
            "last_fetch_ok": last_fetch_ok,
            "last_push_ok": last_push_ok,
            "stalled_since": stalled_since,
            "busy_streak": 0,
            "held": held,
            "quarantined": quarantined,
            "outbound_unrelayable": outbound_unrelayable,
            "rooms": room_stats,
            "channels": channel_stats,
            "git_failed": git_failed,
            "sender_not_homed": sender_not_homed,
            "quiet": bool(quiet),
            "quiet_streak": 0,
        }
        path = destination(settings.root, "bridge", "health.json")
        atomic_replace(
            path,
            (json.dumps(value, sort_keys=True) + "\n").encode("utf-8"),
            settings.root,
        )
        return value


def emit_unwritten_health(reason, write_error, **fields):
    record = {"ts": utc_now(), "action": reason, "health_unwritten": str(write_error)}
    record.update(fields)
    print(json.dumps(record, sort_keys=True, separators=(",", ":")), flush=True)


def write_busy_health(settings):
    # Busy probe: the whole read-modify-write happens under the health lock so
    # the streak and the carried-over fields come from one consistent read.
    with health_lock(settings.root, required=True):
        prior = read_health(settings)
        delay = os.environ.get("BRIDGE_TEST_HEALTH_DELAY_MS")
        if delay:
            time.sleep(float(delay) / 1000.0)
        prior_streak = prior.get("busy_streak", 0)
        busy_streak = prior_streak + 1 if isinstance(prior_streak, int) else 1
        unhealthy = busy_streak >= 5
        prior_ok = prior.get("ok", True)
        if not isinstance(prior_ok, bool):
            prior_ok = True
        prior_reason = prior.get("reason", "busy")
        if not isinstance(prior_reason, str):
            prior_reason = "busy"
        now = utc_now()
        first_tick_at = prior.get("first_tick_at")
        if epoch_from_iso(first_tick_at) is None:
            first_tick_at = now
        ok = False if unhealthy else prior_ok
        outbound_unrelayable = prior.get("outbound_unrelayable", [])
        if not isinstance(outbound_unrelayable, list):
            outbound_unrelayable = []
        value = {
            "ts": now,
            "ok": ok,
            "reason": "busy_streak" if unhealthy else prior_reason,
            "first_tick_at": first_tick_at,
            "last_fetch_ok": prior.get("last_fetch_ok"),
            "last_push_ok": prior.get("last_push_ok"),
            "stalled_since": None if ok else prior.get("stalled_since") or now,
            "busy_streak": busy_streak,
            "held": prior.get("held", 0),
            "quarantined": prior.get("quarantined", 0),
            "outbound_unrelayable": [
                mail_id for mail_id in outbound_unrelayable if isinstance(mail_id, str)
            ][:20],
            "rooms": prior.get(
                "rooms",
                {"published": 0, "collisions": [], "retired": [], "route_contested": 0},
            ),
            "channels": prior.get(
                "channels",
                {
                    "imported": 0,
                    "published": 0,
                    "quarantined": 0,
                    "unpublishable": 0,
                    "diverged": [],
                    "rewritten": [],
                },
            ),
            "git_failed": bounded_git_failures(prior.get("git_failed", [])),
            "sender_not_homed": bounded_hold_summary(prior.get("sender_not_homed", {})),
            "quiet": prior.get("quiet", False),
            "quiet_streak": prior.get("quiet_streak", 0),
        }
        path = destination(settings.root, "bridge", "health.json")
        atomic_replace(
            path,
            (json.dumps(value, sort_keys=True) + "\n").encode("utf-8"),
            settings.root,
        )
        return value


def write_quiet_health(settings):
    """Advance only the quiet tick fields while preserving prior health."""
    with health_lock(settings.root, required=True):
        value = read_health(settings)
        if value.get("ok") is not True:
            raise TickError("quiet_prior_unhealthy")
        streak = value.get("quiet_streak", 0)
        value["ts"] = utc_now()
        value["quiet"] = True
        value["quiet_streak"] = streak + 1 if isinstance(streak, int) else 1
        atomic_replace(
            destination(settings.root, "bridge", "health.json"),
            (json.dumps(value, sort_keys=True) + "\n").encode("utf-8"),
            settings.root,
        )
        return value


def write_fatal_health(root, reason):
    # Exit-2 writer: no mkdir, no chmod, no log file (ruling R5a). It locks
    # only when bridge/.health.lock already exists, so the lock file itself
    # is never created on this path.
    with health_lock(root, required=False):
        path = destination(root, "bridge", "health.json")
        try:
            prior = load_json_bytes(open_regular(path, 64 * 1024), str(path))
        except (FileNotFoundError, ConfigError):
            prior = {}
        if not isinstance(prior, dict):
            prior = {}
        now = utc_now()
        first_tick_at = prior.get("first_tick_at")
        if epoch_from_iso(first_tick_at) is None:
            first_tick_at = now
        last_fetch_ok = prior.get("last_fetch_ok")
        if epoch_from_iso(last_fetch_ok) is None:
            last_fetch_ok = None
        last_push_ok = prior.get("last_push_ok")
        if epoch_from_iso(last_push_ok) is None:
            last_push_ok = None
        value = {
            "ts": now,
            "ok": False,
            "reason": reason,
            "first_tick_at": first_tick_at,
            "last_fetch_ok": last_fetch_ok,
            "last_push_ok": last_push_ok,
            "stalled_since": prior.get("stalled_since") or now,
            "busy_streak": 0,
            "held": 0,
            "quarantined": 0,
            "outbound_unrelayable": [],
            "rooms": prior.get(
                "rooms",
                {"published": 0, "collisions": [], "retired": [], "route_contested": 0},
            ),
            "channels": prior.get(
                "channels",
                {
                    "imported": 0,
                    "published": 0,
                    "quarantined": 0,
                    "unpublishable": 0,
                    "diverged": [],
                    "rewritten": [],
                },
            ),
            "git_failed": bounded_git_failures(prior.get("git_failed", [])),
            "sender_not_homed": bounded_hold_summary(prior.get("sender_not_homed", {})),
            "quiet": False,
            "quiet_streak": 0,
        }
        atomic_replace(
            path, (json.dumps(value, sort_keys=True) + "\n").encode(), root
        )


def relay_size(repo):
    total = 0
    git_dir = repo / ".git"
    if not git_dir.is_dir():
        return 0
    for path in git_dir.rglob("*"):
        try:
            if path.is_file() and not path.is_symlink():
                total += path.stat().st_size
        except OSError:
            pass
    return total


def acquire_tick_lock(settings):
    bridge = destination(settings.root, "bridge")
    ensure_dir(settings.root, bridge)
    path = destination(settings.root, "bridge", ".lock")
    anchor = destination(settings.root, "bridge", ".lock.anchor")
    flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
    initial = os.open(str(path), flags, 0o600)
    os.close(initial)
    try:
        os.link(str(path), str(anchor), follow_symlinks=False)
        fsync_directory(bridge)
    except FileExistsError:
        pass
    descriptor = os.open(
        str(anchor), os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
    )
    canonical = os.fstat(descriptor)
    if not stat.S_ISREG(canonical.st_mode):
        os.close(descriptor)
        raise ConfigError("bridge lock anchor must be a regular file")
    try:
        before = os.stat(str(path), follow_symlinks=False)
    except FileNotFoundError:
        before = None
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        os.close(descriptor)
        return None
    try:
        held = os.fstat(descriptor)
        current = os.stat(str(path), follow_symlinks=False)
    except FileNotFoundError:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)
        return None
    held_identity = (held.st_dev, held.st_ino)
    current_identity = (current.st_dev, current.st_ino)
    before_identity = (
        None if before is None else (before.st_dev, before.st_ino)
    )
    if before_identity == held_identity and current_identity != held_identity:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)
        return None
    if current_identity != held_identity:
        if not stat.S_ISREG(current.st_mode):
            fcntl.flock(descriptor, fcntl.LOCK_UN)
            os.close(descriptor)
            raise ConfigError("bridge lock path must be a regular file")
        path.unlink()
        os.link(str(anchor), str(path), follow_symlinks=False)
        fsync_directory(bridge)
    return descriptor


def ignored_branches(config, git, logger, peers=None):
    result = git.run(
        [
            "for-each-ref",
            "--format=%(refname:strip=4)",
            "refs/remotes/origin/machines/*",
        ]
    )
    for host in sorted(filter(None, result.stdout.splitlines())):
        effective = set(config.peers if peers is None else peers)
        if host not in effective and host != config.host:
            logger.emit("ignored_branch", host=host, reason="unlisted_host")


def execute(check_config=False):
    settings = load_settings()
    deadline = Deadline(settings.deadline_seconds)
    config = load_config(settings)
    git = Git(settings, deadline)
    validate_repo(settings, config, git)
    if check_config:
        validate_post_version(settings)
        print(json.dumps({"ok": True, "host": settings.host}, sort_keys=True))
        return 0
    logger = Logger(settings.root)
    lock_descriptor = acquire_tick_lock(settings)
    try:
        if lock_descriptor is None:
            # Busy probe: inside the try so a missing .health.lock surfaces
            # as internal_error instead of escaping to main() (finding 1).
            health = write_busy_health(settings)
            logger.emit("busy", busy_streak=health["busy_streak"], ok=health["ok"])
            return 0 if health["ok"] else 1
        prior_health = read_health(settings)
        # The start-of-tick probe is what a completed tick consumes, and what
        # step 17 persists: anything landing after it forces the next tick
        # full instead of being recorded as already seen.
        start_fingerprint, start_heads, quiet = tick.quiet_candidate(
            settings, git, prior_health
        )
        if quiet:
            health = write_quiet_health(settings)
            logger.emit("quiet", streak=health["quiet_streak"])
            return 0
        if fence_present(settings):
            logger.emit("fenced", root=str(settings.root))
            write_health(settings, False, "fenced")
            return 1
        # Ruling R1: a malformed rules.json is TickError("rules_invalid"),
        # exit 1 — never config-fatal. Validate before any placeholder or
        # mailbox write; post's own CLI refuses to run against an invalid
        # file, so this also keeps that failure off the internal_error path.
        load_rules(settings)
        recover(settings, git, logger)
        fetch_ok = fetch_remote(settings, git, logger)
        if fetch_ok:
            logger.emit("fetch", ok=True)
        else:
            logger.emit("fetch", ok=False, reason="git_fetch_failed")
        checkpoint("after-fetch")
        oids = pin_remote_oids(git)
        post_rooms = run_post_rooms(settings)
        denied_names = config.channels.deny if config.channels is not None else ()
        # SPEC-v2 §Unpublished senders keys on the peer's own publication
        # history, not on the registry branch: snapshot.v2_peers is that set
        # and binding_verdict consumes it directly. §Registry's "none ever =>
        # config peers alone" governs peer selection only.
        snapshot = rooms.build_snapshot(
            settings,
            config,
            git,
            oids,
            post_rooms,
            logger,
            denied_names=denied_names,
        )
        ignored_branches(config, git, logger, snapshot.peers)
        # Step 8's archive check lives inside import_channels, which owns it
        # and reports through ChannelStats.completed and .rewritten. Running
        # it here too doubled a `git diff` per peer per tick and double-logged
        # relay_history_rewritten.
        if fence_present(settings):
            raise TickError("fenced")
        registered_rooms = rooms.ensure_placeholders(
            settings,
            config,
            snapshot,
            logger,
            deadline,
            lambda: fence_present(settings),
        )
        # r5.5 (M2): binding decisions read the table post itself will use.
        snapshot = dataclass_replace(snapshot, post_rooms=registered_rooms)
        checkpoint("after-placeholders")
        checkpoint("before-inbound")
        if fence_present(settings):
            raise TickError("fenced")
        mail_holds = HoldLedger(settings.root, "held-not-homed")
        held, quarantined = process_inbound(
            settings,
            config,
            git,
            snapshot.real_rooms,
            snapshot.placeholders,
            logger,
            snapshot=snapshot,
            holds=mail_holds,
        )
        checkpoint("before-channel-import")
        if fence_present(settings):
            raise TickError("fenced")
        imported = channels.import_channels(
            settings,
            config.channels,
            git,
            snapshot,
            logger,
            deadline,
            lambda: fence_present(settings),
        )
        for host in snapshot.peers:
            deadline.check()
            oid = snapshot.oids.get(f"machines/{host}")
            if (
                config.channels is not None
                and oid is not None
                and host in imported.completed
            ):
                channels.advance_tip(settings, host, oid)
        fetched_ref = snapshot.oids.get(f"machines/{settings.host}")
        if fetched_ref is None:
            fetched_ref = git.rev("HEAD")
        derive_published_and_tidy(
            settings, config, git, registered_rooms, logger, fetched_ref, tidy=True
        )
        prune_outbox(settings, config, git, logger, snapshot=snapshot)
        selected, outbound_unrelayable = select_outbound(
            settings,
            config,
            snapshot.real_rooms,
            snapshot.placeholders,
            logger,
            deadline,
            snapshot=snapshot,
        )
        copy_outbound(settings, selected, logger)
        rooms.write_rooms_json(settings, snapshot, logger)
        checkpoint("before-publish")
        if fence_present(settings):
            raise TickError("fenced")
        published = channels.publish_channels(
            settings, config.channels, snapshot, logger, deadline
        )
        imported.published += published.published
        imported.unpublishable += published.unpublishable
        for reason, count in published.reasons.items():
            imported.reasons[reason] = imported.reasons.get(reason, 0) + count
        has_queued_work = queued_work(settings, git)
        pushed = commit_and_push(
            settings, config, git, registered_rooms, logger, has_queued_work
        )
        size = relay_size(settings.repo)
        if size > RELAY_WARN_BYTES:
            logger.emit("relay_large", bytes=size, threshold=RELAY_WARN_BYTES)
        # Exit code follows the written health: write_health decides fetch
        # staleness inside the lock and returns the final dict.
        health = write_health(
            settings,
            True,
            "ok",
            held=held,
            quarantined=quarantined,
            outbound_unrelayable=outbound_unrelayable,
            fetch_ok=fetch_ok,
            push_ok=pushed or git.rev("HEAD") == git.rev(fetched_ref),
            room_stats=rooms.rooms_health(snapshot),
            channel_stats=channels.channels_health(imported, settings),
            git_failed=git.read_failures,
            sender_not_homed=mail_holds.summary(snapshot.peers),
            quiet=False,
        )
        logger.emit("health", ok=health["ok"], reason=health["reason"])
        # m5/m6: the quiet fingerprint may only record a tick that actually
        # read every peer. A failed fetch leaves the pinned refs stale and a
        # failed ls-tree skipped a host, so neither checkpoints.
        if fetch_ok and not git.read_failures:
            tick.persist_completed(settings, start_fingerprint, start_heads)
        return 0 if health["ok"] else 1
    except TickError as error:
        logger.emit(error.reason, error=str(error))
        try:
            # This tick's git read failures, not the prior tick's list.
            write_health(
                settings, False, error.reason, git_failed=git.read_failures
            )
        except OSError as write_error:
            # Missing .health.lock on a live path is a misinstall; the record
            # goes to stdout rather than letting the handler's own failure
            # escape as a traceback (C1). The terminal record is the same
            # {action, health_unwritten, class} shape as the catch-all's:
            # the operational reason was already emitted above.
            emit_unwritten_health(
                "internal_error",
                write_error,
                **{"class": type(write_error).__name__},
            )
        return 1
    except ConfigError:
        # Config-fatal (topology collision, unsafe destination, …) exits 2
        # through main(); the R5b catch-all must not swallow it.
        raise
    except Exception as error:  # noqa: BLE001 - R5b mandates the catch-all
        # Ruling R5b: a traceback must never leave health.json stale. The
        # lock descriptor still closes via the finally below.
        logger.emit(
            "internal_error",
            **{"class": type(error).__name__},
            error=str(error),
        )
        try:
            write_health(
                settings, False, "internal_error", git_failed=git.read_failures
            )
        except OSError as write_error:
            emit_unwritten_health(
                "internal_error", write_error, **{"class": type(error).__name__}
            )
        return 1
    finally:
        if lock_descriptor is not None:
            os.close(lock_descriptor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-config", action="store_true")
    args = parser.parse_args()
    try:
        return execute(check_config=args.check_config)
    except ConfigError as error:
        record = {"ts": utc_now(), "action": "config_error", "error": str(error)}
        if args.check_config:
            print(json.dumps(record, sort_keys=True, separators=(",", ":")), flush=True)
            return 2
        # Ruling R5a: on exit 2 the only permitted write is
        # bridge/health.json, and only when POST_MAIL_ROOT itself validated
        # and bridge/ already exists — no Logger, no log.jsonl line, no
        # mkdir, no chmod. The JSON record always goes to stdout.
        emitted = False
        root_raw = os.environ.get("POST_MAIL_ROOT")
        required_present = all(
            os.environ.get(name)
            for name in (
                "POST_MAIL_ROOT",
                "BRIDGE_REPO",
                "BRIDGE_HOST",
                "BRIDGE_SSH_KEY",
            )
        )
        if root_raw and required_present:
            root = Path(root_raw)
            if root.is_absolute() and root.is_dir() and realpath_equal(root):
                bridge = root / "bridge"
                if bridge.is_dir() and not bridge.is_symlink():
                    try:
                        write_fatal_health(root, "config_error")
                        emitted = True
                    except (ConfigError, OSError):
                        pass
        print(json.dumps(record, sort_keys=True, separators=(",", ":")), flush=True)
        if not emitted:
            print(f"post-bridge: {error}", file=sys.stderr)
        return 2
    except subprocess.TimeoutExpired as error:
        print(
            json.dumps(
                {"ts": utc_now(), "action": "deadline", "error": str(error)},
                sort_keys=True,
                separators=(",", ":"),
            ),
            flush=True,
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
