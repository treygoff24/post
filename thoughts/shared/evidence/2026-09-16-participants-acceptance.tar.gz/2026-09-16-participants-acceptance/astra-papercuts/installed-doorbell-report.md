# Installed doorbell channels compatibility receipt

Final harness command:

```sh
/tmp/post-papercuts-2026-09-15/installed-doorbell-channels-compat.sh
```

Harness rc/output:

```text
rc=0
PASS installed doorbell channels compatibility
run_root=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE
participant_id=shell-2a8c633e
codex_rc=0 systemd_rc=0
```

## Commands

```text
run_root=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE
rc=0 env -u POST_MAIL_ROOT -u POST_PARTICIPANT -u POST_ARX_GENERATION HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home /Users/treygoff/.local/bin/post version --json
rc=0 HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail /Users/treygoff/.local/bin/post doctor --fix
rc=0 HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail /Users/treygoff/.local/bin/post rooms add compat-room /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/workspaces/compat-room --json
rc=0 HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail /Users/treygoff/.local/bin/post rooms add participant-room /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/workspaces/participant-room --json
rc=0 cd /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/workspaces/participant-room && HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail /Users/treygoff/.local/bin/post participant bind --harness shell --key doorbell-compat --workspace participant-room --json
rc=0 cd /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/workspaces/participant-room && HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail POST_PARTICIPANT=shell-2a8c633e /Users/treygoff/.local/bin/post chat compat-channel --join --json
rc=0 HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/runtime-home POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail /Users/treygoff/.local/bin/post channels --json
rc=0 POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail POST_CODEX_DOORBELL_PLATFORM=darwin POST_CODEX_DOORBELL_HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/codex-home POST_CODEX_DOORBELL_INSTALL_DIR=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/codex-hooks POST_CODEX_DOORBELL_POST_BIN=/Users/treygoff/.local/bin/post POST_CODEX_DOORBELL_HERDR_BIN=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/stubs/herdr POST_CODEX_DOORBELL_LAUNCHCTL_BIN=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/stubs/launchctl node /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/frozen-hooks/install-codex-doorbell.mjs --room compat-room --agent compat-macos --channel compat-channel --interval-seconds 7
rc=0 POST_MAIL_ROOT=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/mail POST_CODEX_DOORBELL_PLATFORM=linux POST_CODEX_DOORBELL_HOME=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/systemd-home POST_CODEX_DOORBELL_INSTALL_DIR=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/systemd-hooks POST_CODEX_DOORBELL_POST_BIN=/Users/treygoff/.local/bin/post POST_CODEX_DOORBELL_HERDR_BIN=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/stubs/herdr POST_CODEX_DOORBELL_SYSTEMCTL_BIN=/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/stubs/systemctl node /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/frozen-hooks/install-systemd-doorbell.mjs --room compat-room --agent compat-linux --channel compat-channel --interval-seconds 7
```

## Real channels JSON

```json
{"ok":true,"channels":[{"created":"2026-09-16 10:14:38 -0500","created_by":"participant-room","members":["compat-room","participant-room"],"messages":1,"name":"compat-channel","participants":["shell-2a8c633e"],"room":null,"unread":null}],"count":1,"participant":"unbound","pending":0,"participant_fix":"run: post participant bind"}
```

## Installer output

Codex launchd rc=0, stderr empty:

```text
doorbell installed
monitor updated
launch agent updated
```

systemd rc=0, stderr empty:

```text
doorbell installed
monitor updated
service updated
timer updated
```

Fake launchctl calls:

```jsonl
["bootout","gui/501/dev.post.codex-doorbell.compat-macos"]
["bootstrap","gui/501","/tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE/codex-home/Library/LaunchAgents/dev.post.codex-doorbell.compat-macos.plist"]
```

Fake systemctl calls:

```jsonl
["--user","daemon-reload"]
["--user","enable","--now","post-codex-doorbell@compat-linux.timer"]
```

## Assertions

```text
PASS installed binary build_sha is a500bd2 with store_version 2 and all four capabilities
PASS real post channels --json kept compat-room from legacy members.json
PASS real post channels --json added participant-room to members and shell-2a8c633e to participants
PASS real post channels --json left legacy members.json byte-identical
PASS Codex launchd installer accepted the real channels JSON and exited 0
PASS isolated launchctl stub received bootout and bootstrap
PASS isolated plist pins compat-channel and /Users/treygoff/.local/bin/post
PASS systemd installer accepted the real channels JSON and exited 0
PASS isolated systemctl stub received daemon-reload and enable
PASS isolated service pins compat-channel and /Users/treygoff/.local/bin/post
SCOPE this proves installer channels-JSON compatibility only; participant-scoped idle wake remains unproved and unchanged
RUN_ROOT /tmp/post-papercuts-2026-09-15/installed-doorbell-run.lruBYE
```
